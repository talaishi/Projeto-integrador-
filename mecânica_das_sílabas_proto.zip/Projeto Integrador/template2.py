from flask import Flask, render_template
import random

flask = Flask(__name__)

palavras = [
        "O&to&rri&no&la&rin&go&lo&gis&ta",
        "Car&dio&lo&gis&ta",
        "Der&ma&to&lo&gis&ta",
        "Neu&ro&lo&gis&ta",
        "Pe&di&a&tra",
    ]

colors = [
    "#FF0000","#00FF00","#0000FF","#FFFF00","#00FFFF",
    "#FF00FF","#FFA500","#800080","#FFC0CB","#A52A2A",
    "#808080","#FFFFFF","#008000","#000080",
    "#800000","#008080","#C0C0C0","#FFD700","#4B0082",
]

# ==================================================================================================
# Funções
# ==================================================================================================

# A palavra escolhida

def escolher_palavra_específica(palavra, cor):

    palavra_escolhida = palavra

    silabas_escolhidas = palavra_escolhida.split("&")

    cor_escolhida = cor

    silabas_escolhidas_com_ids = [(id, silaba, cor_escolhida) for id, silaba in enumerate(silabas_escolhidas)]

    return silabas_escolhidas_com_ids

# Palavras aleatórias

def escolher_palavras_aleatórias(lista_palavras):
    list = []
    id_atual = 0

    for palavra in lista_palavras:
        #list.extend(escolher_palavra_específica(i, random.choice(colors)))
        cor = random.choice(colors)

        for silaba in palavra.split('&'):
            list.append((id_atual, silaba, cor))
            id_atual += 1

    return list

    #print(f"\n\nLista das palavras aleatórias:\n\n{list}")

# Função de printar

def printar(def1, def2):

    if not def2 or def2 == "":
        def2 = []

    print(f"\n\nLista da palavra escolhida:\n\n{def1}")
    print(f"\n\nLista das palavras escolhidas:\n\n{def2}")

# ==================================================================================================
# Rotas
# ================================================================================================== 

@flask.route('/')
def index():
    silabas_específicas = escolher_palavra_específica(palavras[2], colors[4])
    silabas_aleatórias = escolher_palavras_aleatórias(palavras)

    random.shuffle(silabas_aleatórias)
    random.shuffle(silabas_específicas)

    #print("Silabas específicas:", silabas_específicas)
    #print("Silabas aleatórias:", silabas_aleatórias)

    return render_template(
        'index.html',
        silabas_específicas=silabas_específicas,
        silabas_aleatórias=silabas_aleatórias
    )

if __name__ == '__main__':
    flask.run(debug=True)