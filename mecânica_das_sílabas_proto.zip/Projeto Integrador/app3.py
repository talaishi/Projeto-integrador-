import random

palavras = [
        "O&to&rri&no&la&rin&go&lo&gis&ta",
        "Car&dio&lo&gis&ta",
        "Der&ma&to&lo&gis&ta",
        "Neu&ro&lo&gis&ta",
        "Pe&di&a&tra",
    ]

colors = [
    "#FF0000","#00FF00","#0000FF","#FFFF00","#00FFFF",
    "#FF00FF","#FFA500","#800080","#FFC0CB","#A52A2A",
    "#808080","#000000","#FFFFFF","#008000","#000080",
    "#800000","#008080","#C0C0C0","#FFD700","#4B0082",
]

# A palavra escolhida

def escolher_palavra_específica(palavra, cor):

    palavra_escolhida = palavra

    silabas_escolhidas = palavra_escolhida.split("&")

    cor_escolhida = cor

    silabas_escolhidas_com_ids = [[id, silaba, cor_escolhida] for id, silaba in enumerate(silabas_escolhidas)]

    for i in silabas_escolhidas_com_ids:
        for id, silaba in i:
            if silaba == silaba:
                id = 50

    silabas_escolhidas_com_ids_final = [[id, silaba, cor_escolhida] for id, silaba in enumerate(silabas_escolhidas)]

    return silabas_escolhidas_com_ids_final

# Palavras aleatórias

def escolher_palavras_aleatórias(lista_palavras):
    list = []

    for i in lista_palavras:
        list.append(escolher_palavra_específica(i, random.choice(colors)))

    return list

    #print(f"\n\nLista das palavras aleatórias:\n\n{list}")

# Função de printar

def printar(def1, def2):

    if not def2 or def2 == "":
        def2 = []

    print(f"\n\nLista da palavra escolhida:\n\n{def1}")
    print(f"\n\nLista das palavras escolhidas:\n\n{def2}")

#printar(escolher_palavra_específica(palavras[2], colors[6]), escolher_palavras_aleatórias(palavras))

def printar2():
    silabas_específicas = escolher_palavra_específica(palavras[2], colors[4])
    silabas_aleatórias = escolher_palavras_aleatórias(palavras)

    random.shuffle(silabas_aleatórias)
    random.shuffle(silabas_específicas)

    silabas = silabas_aleatórias + silabas_específicas

    random.shuffle(silabas)

    print("Silabas específicas:", silabas_específicas)
    print("Silabas aleatórias:", silabas_aleatórias)

#a = escolher_palavra_específica("Ba&na&na", colors[2])
# Descobrir silabas parecidas em uma palavra específica
palavra = escolher_palavra_específica("Ba&na&na", colors[6])
for i in range(len(palavra)):
    if i < len(palavra) - 1:
        if palavra[i][1] == palavra[i + 1][1]:
            print(f"Silabas iguais: {palavra[i][1]} e {palavra[i + 1][1]}")
#print(a)