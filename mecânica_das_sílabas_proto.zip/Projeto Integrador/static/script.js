const item = document.getElementById('drag-item');
const boxes = document.querySelectorAll('.box');

// 1. When the user starts dragging the item
item.addEventListener('dragstart', (e) => {
  // Store the ID of the dragged element in the dataTransfer object
  e.dataTransfer.setData('text/plain', e.target.id);
});

// Loop through both containers to attach drop zone logic
boxes.forEach(box => {
  // 2. Prevent default behavior to allow a drop
  box.addEventListener('dragover', (e) => {
    e.preventDefault(); 
  });

  // 3. Handle the actual drop
  box.addEventListener('drop', (e) => {
    e.preventDefault();
    // Get the stored ID of the dragged element
    const id = e.dataTransfer.getData('text/plain');
    const draggableElement = document.getElementById(id);
    
    // Append the element to the container it was dropped into
    box.appendChild(draggableElement);
  });
});
