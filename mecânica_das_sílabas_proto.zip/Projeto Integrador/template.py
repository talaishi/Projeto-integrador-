from flask import Flask, render_template
import random

flask = Flask(__name__)

palavras = [
        #"O&to&rri&no&la&rin&go&lo&gis&ta",
        #"Car&dio&lo&gis&ta",
        #"Der&ma&to&lo&gis&ta",
        #"Neu&ro&lo&gis&ta",
        #"Pe&di&a&tra",
        "Ba&na&na",
        "Goi&a&ba",
        "A&ba&po&ru",
        "Re&nan&play",
        "C&thu&lhu",
        "Sho&ggoth"
    ]

colors = [
    "#FF0000","#00FF00","#0000FF","#FFFF00","#00FFFF",
    "#FF00FF","#FFA500","#800080","#FFC0CB","#A52A2A",
    "#808080","#FFFFFF","#008000","#000080",
    "#800000","#008080","#C0C0C0","#FFD700","#4B0082",
]

# ==================================================================================================
# Funções
# ==================================================================================================

# A palavra escolhida

def escolher_palavra_específica(palavra, cor):

    palavra_escolhida = palavra

    silabas_escolhidas = palavra_escolhida.split("&")

    cor_escolhida = cor

    silabas_escolhidas_finais = [(silaba, cor_escolhida) for silaba in silabas_escolhidas]

    return silabas_escolhidas_finais


def escolher_palavras_aleatórias(lista_palavras, palavra_escolhida, cor_escolhida):
    list = []

    for palavra in lista_palavras:
        if palavra != palavra_escolhida:
            #list.extend(escolher_palavra_específica(i, random.choice(colors)))
            cor = random.choice([color for color in colors if color != cor_escolhida])

            for silaba in palavra.split('&'):
                list.append((silaba, cor))

    return list

    #print(f"\n\nLista das palavras aleatórias:\n\n{list}")


def printar(def1, def2):

    if not def2 or def2 == "":
        def2 = []

    print(f"\n\nLista da palavra escolhida:\n\n{def1}")
    print(f"\n\nLista das palavras escolhidas:\n\n{def2}")


palavra_escolhida = palavras[2]
cor_escolhida = colors[4]

silabas_específicas = escolher_palavra_específica(palavra_escolhida, cor_escolhida)
silabas_aleatórias = escolher_palavras_aleatórias(palavras, palavra_escolhida, cor_escolhida)

print(silabas_aleatórias)
print(silabas_específicas)

# ==================================================================================================
# Rotas
# ================================================================================================== 

@flask.route('/')
def index():

    palavra_escolhida = palavras[3]
    cor_escolhida = colors[8]

    var_palavra = palavra_escolhida.replace("&", "")

    silabas_específicas = escolher_palavra_específica(palavra_escolhida, cor_escolhida)
    silabas_aleatórias = escolher_palavras_aleatórias(palavras, palavra_escolhida, cor_escolhida)
    silabas = silabas_aleatórias + silabas_específicas

    random.shuffle(silabas)

    return render_template(
        'index.html',
        silabas=silabas,
        silabas_específicas=silabas_específicas,
        var_palavra=var_palavra,
        var_cor=cor_escolhida
    )

def run():
    flask.run(debug=True)

run()