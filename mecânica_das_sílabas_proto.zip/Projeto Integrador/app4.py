from app3 import colors

def escolher_palavra_específica(palavra, cor):

    palavra_escolhida = palavra

    silabas_escolhidas = palavra_escolhida.split("&")

    cor_escolhida = cor

    silabas_escolhidas_com_ids = [[id, silaba, cor_escolhida] for id, silaba in enumerate(silabas_escolhidas)]

    for i in silabas_escolhidas_com_ids:
        for id, silaba in i:
            if silaba == silaba:
                id = 50

    silabas_escolhidas_com_ids_final = [[id, silaba, cor_escolhida] for id, silaba in enumerate(silabas_escolhidas)]

    return silabas_escolhidas_com_ids_final


# Descobrir silabas parecidas em uma palavra específica
palavra = escolher_palavra_específica("Ba&na&na", colors[6])

for i in range(len(palavra)):
    if i < len(palavra) - 1:
        if palavra[i][1] == palavra[i + 1][1]:
            print(f"Silabas iguais: {palavra[i][1]} e {palavra[i + 1][1]}")